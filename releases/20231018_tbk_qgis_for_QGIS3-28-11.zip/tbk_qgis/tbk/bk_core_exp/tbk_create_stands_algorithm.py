# -*- coding: utf-8 -*-

#######################################################################
# Main algorithm for stand generation as stand-alone algorithm for QGIS
#
# (C) Dominique Weber, Christoph Schaller, Hannes Horneber, HAFL
#######################################################################

"""
/***************************************************************************
 TBk-QGIS plugin: Toolkit for the generation of forest stand maps
                              -------------------
        created              : 2023-02-08
        copyright            : (C) 2023 by Berner Fachhochschule HAFL
        email                : christian.rosset@bfh.ch
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

__author__ = 'Berner Fachhochschule HAFL'
__date__ = '2020-08-03'
__copyright__ = '(C) 2020 by Berner Fachhochschule HAFL'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

if __name__ == "__main__":  # this will be invoked if this module is being run directly, but not via import!
    __package__ = 'bk_core'  # make sure relative imports work when testing

import os
from shutil import copyfile
from datetime import datetime, time, timedelta
import logging, logging.handlers
import sys

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (QgsProcessing,
                       QgsFeatureSink,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingParameterFolderDestination,
                       QgsProcessingParameterString,
                       QgsProcessingParameterBoolean,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterDefinition,
                       QgsApplication)

# from .resources import *
# from tbk_qgis.tbk.utility.tbk_utilities import *
from tbk_utilities import ensure_dir, QgisHandler

from .tbk_create_stands import *


class AlgorithmCreateStands(QgsProcessingAlgorithm):
    """
    QgsProcessingAlgorithm that wraps stand creation.
    Input: VHM, MG
    Output: Raster with stand IDs

    All Processing algorithms should extend the QgsProcessingAlgorithm
    class to be available in all elements.
    """

    def addAdvancedParameter(self, parameter):
        parameter.setFlags(parameter.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        return self.addParameter(parameter)

    def addHiddenParameter(self, parameter):
        parameter.setFlags(parameter.flags() | QgsProcessingParameterDefinition.FlagHidden)
        return self.addParameter(parameter)

    # Constants used to refer to parameters and outputs. They will be
    # used when calling the algorithm from another algorithm, or when
    # calling from the QGIS console.

    OUTPUT = "OUTPUT"

    # Directory containing the input files
    OUTPUT_ROOT = "output_root"
    # Directory containing the input files
    WORKING_ROOT = "working_root"
    # VHM 10m as main TBk input
    VHM_10M = "vhm_10m"
    # VHM 150cm to calculate DG
    VHM_150CM = "vhm_150cm"
    # Coniferous raster to calculate stand mean
    CONIFEROUS_RASTER = "coniferous_raster"
    # Perimeter shapefile to clip final result
    PERIMETER = "perimeter"

    # Whether to clip the VHM prior to classification
    CLIP_VHM_BEFORE = "clip_vhm_before"

    # Default log file name
    # Will be stored in the result directory
    LOGFILE_NAME = "logfile_name"

    # Main TBk parameters (for details see run_stand_classification function)
    # If to consider it for classification
    USE_CONFEROUS_FOR_CLASSIFICATION = "useConiferousRasterForClassification"
    # Zone raster
    ZONE_RASTER_FILE = "zoneRasterFile"
    # Short description
    DESCRIPTION = "description"
    # Relative min tolerance
    MIN_TOL = "min_tol"
    # Relative max tolerance
    MAX_TOL = "max_tol"
    # Extension of the range down [m]
    MIN_CORR = "min_corr"
    # Extension of the range up [m]
    MAX_CORR = "max_corr"
    # Minimum relative amount of valid cells
    MIN_VALID_CELLS = "min_valid_cells"
    # Minimum cells per stand
    MIN_CELLS_PER_STAND = "min_cells_per_stand"
    # Minimum cells for pure mixture stands
    MIN_CELLS_PER_PURE_STAND = "min_cells_per_pure_stand"
    # VHM minimum height
    VHM_MIN_HEIGHT = "vhm_min_height"
    # VHM maximum height
    VHM_MAX_HEIGHT = "vhm_max_height"
    # Simplification tolerance
    SIMPLIFICATION_TOLERANCE = "simplification_tolerance"

    # Additional parameters
    # Min. area to eliminate small stands
    MIN_AREA_M2 = "min_area_m2"
    # Min. area to merge similar stands
    SIMILAR_NEIGHBOURS_MIN_AREA_M2 = "similar_neighbours_min_area"
    # hdom relative diff to merge similar stands
    SIMILAR_NEIGHBOURS_HDOM_DIFF_REL = "similar_neighbours_hdom_diff_rel"
    # Also calc coniferous prop. for main layer
    CALC_MIXTURE_FOR_MAIN_LAYER = "calc_mixture_for_main_layer"
    # Delete temporary files and fields
    DEL_TMP = "del_tmp"

    def initAlgorithm(self, config):
        """
        Here we define the inputs and output of the algorithm, along
        with some other properties.
        """

        ## Directory containing the input files
        # "working_root": r'C:\school\hafl\TBk-master_20200608\test_dataset',

        # VHM 10m as main TBk input
        self.addParameter(QgsProcessingParameterRasterLayer(self.VHM_10M, self.tr("VHM 10m as main TBk input  (.tif)")))
        # VHM 150cm to calculate DG
        self.addParameter(
            QgsProcessingParameterRasterLayer(self.VHM_150CM, self.tr("VHM 150cm to calculate DG (.tif)")))
        # Coniferous raster to calculate stand mean
        self.addParameter(QgsProcessingParameterRasterLayer(self.CONIFEROUS_RASTER,
                                                            self.tr("Coniferous raster to calculate stand mean (.tif)"),
                                                            optional=True))
        # Perimeter shapefile to clip final result
        self.addParameter(QgsProcessingParameterFeatureSource(self.PERIMETER, self.tr(
            "Perimeter shapefile to clip final result (.shp)"), [QgsProcessing.TypeVectorPolygon]))

        # Folder for algo output
        self.addParameter(QgsProcessingParameterFolderDestination(self.OUTPUT_ROOT, self.tr('Output folder')))

        parameter = QgsProcessingParameterBoolean(self.USE_CONFEROUS_FOR_CLASSIFICATION,
                                                  self.tr("Consider coniferous raster for classification"),
                                                  defaultValue=True)
        self.addAdvancedParameter(parameter)

        # Zone raster
        parameter = QgsProcessingParameterRasterLayer(self.ZONE_RASTER_FILE, self.tr("Zone raster (.tif)"),
                                                      optional=True)
        self.addHiddenParameter(parameter)

        parameter = QgsProcessingParameterString(self.LOGFILE_NAME, self.tr("Log File Name (.log)"),
                                                 defaultValue="tbk_processing.log")
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterString(self.DESCRIPTION, self.tr("Short description"),
                                                 defaultValue="TBk dataset")
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.MIN_TOL, self.tr("Relative min tolerance"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=0.1)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.MAX_TOL, self.tr("Relative max tolerance"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=0.1)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.MIN_CORR, self.tr("Extension of the range down [m]"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=4)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.MAX_CORR, self.tr("Extension of the range up [m]"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=4)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.MIN_VALID_CELLS,
                                                 self.tr("Minimum relative amount of valid cells"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=0.5)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.MIN_CELLS_PER_STAND, self.tr("Minimum cells per stand"),
                                                 type=QgsProcessingParameterNumber.Integer, defaultValue=10)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.MIN_CELLS_PER_PURE_STAND,
                                                 self.tr("Minimum cells for pure mixture stands"),
                                                 type=QgsProcessingParameterNumber.Integer, defaultValue=30)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.VHM_MIN_HEIGHT, self.tr("VHM minimum height"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=0)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.VHM_MAX_HEIGHT, self.tr("VHM maximum height"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=60)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.SIMPLIFICATION_TOLERANCE, self.tr("Simplification tolerance [m]"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=8)
        self.addAdvancedParameter(parameter)

        #    # Additional parameters
        parameter = QgsProcessingParameterNumber(self.MIN_AREA_M2, self.tr("Min. area to eliminate small stands"),
                                                 type=QgsProcessingParameterNumber.Integer, defaultValue=1000)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.SIMILAR_NEIGHBOURS_MIN_AREA_M2,
                                                 self.tr("Min. area to merge similar stands"),
                                                 type=QgsProcessingParameterNumber.Integer, defaultValue=2000)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterNumber(self.SIMILAR_NEIGHBOURS_HDOM_DIFF_REL,
                                                 self.tr("hdom relative diff to merge similar stands"),
                                                 type=QgsProcessingParameterNumber.Double, defaultValue=0.15)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterBoolean(self.CALC_MIXTURE_FOR_MAIN_LAYER,
                                                  self.tr("Also calc coniferous prop. for main layer"),
                                                  defaultValue=True)
        self.addAdvancedParameter(parameter)

        parameter = QgsProcessingParameterBoolean(self.DEL_TMP, self.tr("Delete temporary files and fields"),
                                                  defaultValue=True)
        self.addAdvancedParameter(parameter)

        # parameter = QgsProcessingParameterBoolean(self.CLIP_VHM_BEFORE, self.tr("Clip VHM before classification"), defaultValue=False)
        # self.addAdvancedParameter(parameter)

    def processAlgorithm(self, parameters, context, feedback):
        """
        Here is where the processing itself takes place.
        """

        output_root = self.parameterAsString(parameters, self.OUTPUT_ROOT, context)

        # settings_path = QgsApplication.qgisSettingsDirPath()
        # tbk_tool_path = os.path.join(settings_path,"python/plugins/tbk_qgis")
        tbk_tool_path = os.path.dirname(__file__)

        vhm_10m = str(self.parameterAsRasterLayer(parameters, self.VHM_10M, context).source())
        if not os.path.splitext(vhm_10m)[1].lower() in (".tif", ".tiff"):
            raise QgsProcessingException("vhm_10m must be a TIFF file")
        vhm_150cm = str(self.parameterAsRasterLayer(parameters, self.VHM_150CM, context).source())
        if not os.path.splitext(vhm_150cm)[1].lower() in (".tif", ".tiff"):
            raise QgsProcessingException("vhm_150cm must be a TIFF file")

        useConiferousRaster = self.parameterAsBool(parameters, self.USE_CONFEROUS_FOR_CLASSIFICATION, context)
        coniferous_raster_layer = self.parameterAsRasterLayer(parameters, self.CONIFEROUS_RASTER, context)
        coniferous_raster = None
        if coniferous_raster_layer:
            coniferous_raster = str(coniferous_raster_layer.source())
        if coniferous_raster and (not os.path.splitext(coniferous_raster)[1].lower() in (".tif", ".tiff")):
            raise QgsProcessingException("coniferous_raster must be a TIFF file")
        if useConiferousRaster and coniferous_raster == None:
            raise QgsProcessingException("coniferous_raster is not not specified")

        perimeter = str(self.parameterAsVectorLayer(parameters, self.PERIMETER, context).source())

        if "|layername=" in perimeter.lower():
            perimeter = perimeter.split("|")[0]

        # if not os.path.splitext(perimeter)[1].lower() in (".shp"):
        # if not (".shp" in perimeter.lower()):
        if not os.path.splitext(perimeter)[1].lower() in (".shp"):
            raise QgsProcessingException("perimeter must be a ESRI Shape file")

        zoneRasterFile_layer = self.parameterAsRasterLayer(parameters, self.ZONE_RASTER_FILE, context)
        zoneRasterFile = None
        if zoneRasterFile_layer:
            zoneRasterFile = str(zoneRasterFile_layer.source())
        if zoneRasterFile and (not os.path.splitext(zoneRasterFile)[1].lower() in (".tif", ".tiff")):
            raise QgsProcessingException("zoneRasterFile must be a TIFF file")
        if (not zoneRasterFile) or (zoneRasterFile == "") or zoneRasterFile == None:
            zoneRasterFile = "null"

        logfile_name = str(self.parameterAsString(parameters, self.LOGFILE_NAME, context))
        if (not logfile_name) or logfile_name == "":
            raise QgsProcessingException("no logfile name specified")

        description = str(self.parameterAsString(parameters, self.DESCRIPTION, context))
        if (not description) or description == "":
            description = "TBk dataset"

        min_tol = self.parameterAsDouble(parameters, self.MIN_TOL, context)
        max_tol = self.parameterAsDouble(parameters, self.MAX_TOL, context)
        min_corr = self.parameterAsDouble(parameters, self.MIN_CORR, context)
        max_corr = self.parameterAsDouble(parameters, self.MAX_CORR, context)
        min_valid_cells = self.parameterAsDouble(parameters, self.MIN_VALID_CELLS, context)
        min_cells_per_stand = self.parameterAsInt(parameters, self.MIN_CELLS_PER_STAND, context)
        min_cells_per_pure_stand = self.parameterAsInt(parameters, self.MIN_CELLS_PER_PURE_STAND, context)
        vhm_min_height = self.parameterAsDouble(parameters, self.VHM_MIN_HEIGHT, context)
        vhm_max_height = self.parameterAsDouble(parameters, self.VHM_MAX_HEIGHT, context)

        simplification_tolerance = self.parameterAsDouble(parameters, self.SIMPLIFICATION_TOLERANCE, context)

        min_area_m2 = self.parameterAsInt(parameters, self.MIN_AREA_M2, context)
        similar_neighbours_min_area = self.parameterAsInt(parameters, self.SIMILAR_NEIGHBOURS_MIN_AREA_M2, context)
        similar_neighbours_hdom_diff_rel = self.parameterAsDouble(parameters, self.SIMILAR_NEIGHBOURS_HDOM_DIFF_REL,
                                                                  context)
        calc_mixture_for_main_layer = self.parameterAsBool(parameters, self.CALC_MIXTURE_FOR_MAIN_LAYER, context)
        if calc_mixture_for_main_layer and coniferous_raster == None:
            raise QgsProcessingException("coniferous_raster is not not specified")

        del_tmp = self.parameterAsBool(parameters, self.DEL_TMP, context)

        # clip_vhm_before = self.parameterAsBool(parameters, self.CLIP_VHM_BEFORE, context)

        ensure_dir(output_root)
        working_root = output_root

        # Configure logging
        logfile_tmp_path = os.path.join(working_root, logfile_name)

        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s; %(processName)s; %(levelname)s; %(name)s; %(message)s",
            handlers=[
                logging.FileHandler(logfile_tmp_path, mode='w'),
                QgisHandler(feedback),
                logging.StreamHandler()
            ])

        rootLogger = logging.getLogger()

        rootLogger.info('Run TBk')

        ###################
        # Run TBk
        start_time = time.time()

        coniferous_raster_for_classification = 'null'
        if (useConiferousRaster):
            coniferous_raster_for_classification = coniferous_raster

        # if clip_vhm_before:
        #     rootLogger.info('Clipping VHM 10m before stand delineation')
        #     vhm_10m = clip_vhm_to_perimeter(working_root,vhm_10m,perimeter,"vhm_10m_clipped.tiff")

        # Stand delineation
        rootLogger.info('Stand delineation')
        tbk_result_dir = run_stand_classification(working_root, vhm_10m, coniferous_raster_for_classification,
                                                  zoneRasterFile, description,
                                                  min_tol, max_tol,
                                                  min_corr, max_corr,
                                                  min_valid_cells, min_cells_per_stand, min_cells_per_pure_stand,
                                                  vhm_min_height, vhm_max_height)

        # Simplify & Eliminate
        rootLogger.info('Simplify & Eliminate')
        post_process(tbk_result_dir, min_area_m2, simplification_tolerance=simplification_tolerance, del_tmp=del_tmp)

        # Merge similar neighbours
        rootLogger.info('Merge similar neighbours')
        merge_similar_neighbours(tbk_result_dir, similar_neighbours_min_area, similar_neighbours_hdom_diff_rel,
                                 del_tmp=del_tmp)

        # Clip to perimeter and eliminate gaps
        rootLogger.info('Clip to perimeter and eliminate gaps')
        # run clip function
        clip_to_perimeter(tbk_result_dir, perimeter, del_tmp=del_tmp)
        # run gaps function
        eliminate_gaps(tbk_result_dir, perimeter, del_tmp=del_tmp)

        # Calculate DG
        rootLogger.info('Calculate DG')
        calculate_dg(tbk_result_dir, vhm_150cm, del_tmp=del_tmp)

        # Add coniferous proportion
        if calc_mixture_for_main_layer:
            rootLogger.info('Add coniferous proportion')
            add_coniferous_proportion(tbk_result_dir, coniferous_raster, calc_mixture_for_main_layer, del_tmp=del_tmp)

        # Calc specific attributes and write final shapefile
        rootLogger.info('Calc specific attributes and write final shapefile')
        calc_attributes(tbk_result_dir, del_tmp=del_tmp)

        # Clean up unneeded fields
        if del_tmp:
            del_fields = ["FID_orig", "OBJECTID"]
            result_shape_path = os.path.join(tbk_result_dir, "TBk_Bestandeskarte.shp")
            delete_fields(QgsVectorLayer(result_shape_path, "layer", "ogr"), del_fields)

        # Create default Project
        rootLogger.info('Create default Project')
        # os.system("\"" + arcgis_python + "\" " + tbk_tool_path + "\\post_processing_arcpy\\create_mxd.py" +
        #           " " + tbk_result_dir + " " + tbk_tool_path + " " + working_root + " " + vhm_10m + " " + vhm_150cm)
        # Run Script in separate process since otherwise the current project would be unloaded
        qgisPath = QgsApplication.prefixPath()
        qgisPythonPath = os.path.join(qgisPath, "python")
        if "PYTHONPATH" in os.environ:
            os.environ["PYTHONPATH"] = qgisPythonPath + os.pathsep + os.environ["PYTHONPATH"]
        else:
            os.environ["PYTHONPATH"] = qgisPythonPath
        script_path = os.path.join(tbk_tool_path, "create_project.py")

        command = "python3.exe \"" + script_path.replace("\\", "/") + "\" \"" + tbk_result_dir.replace("\\",
                                                                                                       "/") + "\" \"" \
                  + tbk_tool_path.replace("\\", "/") + "\" \"" + working_root.replace("\\", "/") + "\" \"" \
                  + vhm_10m + "\" \"" + vhm_150cm + "\""

        rootLogger.info(command)
        os.system(command)

        # if del_tmp:
        #     output_tmp_folder = os.path.join(tbk_result_dir,"tmp")
        #     if os.path.isdir(output_tmp_folder):
        #         shutil.rmtree(output_tmp_folder)

        # finished
        feedback.pushInfo("====================================================================")
        feedback.pushInfo("FINISHED")
        feedback.pushInfo("TOTAL PROCESSING TIME: %s (h:min:sec)" % str(timedelta(seconds=(time.time() - start_time))))
        feedback.pushInfo("====================================================================")
        rootLogger.info('FINISHED')

        #        # # copy temporary logfile to result directory
        #        # logfile = os.path.join(tbk_result_dir, config["logfile_name"])
        #        # print("Saving logfile under: %s" % logfile)
        #        # copyfile(config["logfile_tmp_path"], logfile)

        #        # Compute the number of steps to display within the progress bar and
        #        # get features from source
        #        total = 100.0 / source.featureCount() if source.featureCount() else 0
        #        features = source.getFeatures()
        #
        #        for current, feature in enumerate(features):
        #            # Stop the algorithm if cancel button has been clicked
        #            if feedback.isCanceled():
        #                break
        #
        #            # Add a feature in the sink
        #            #sink.addFeature(feature, QgsFeatureSink.FastInsert)
        #
        #            # Update the progress bar
        #            feedback.setProgress(int(current * total))

        # Return the results of the algorithm. In this case our only result is
        # the feature sink which contains the processed features, but some
        # algorithms may return multiple feature sinks, calculated numeric
        # statistics, etc. These should all be included in the returned
        # dictionary, with keys matching the feature corresponding parameter
        # or output names.
        return {self.OUTPUT: working_root}

    def name(self):
        """
        Returns the algorithm name, used for identifying the algorithm. This
        string should be fixed for the algorithm, and must not be localised.
        The name should be unique within each provider. Names should contain
        lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'Generate BK'

    def displayName(self):
        """
        Returns the translated algorithm name, which should be used for any
        user-visible display of the algorithm name.
        """
        return self.tr(self.name())

    def group(self):
        """
        Returns the name of the group this algorithm belongs to. This string
        should be localised.
        """
        # return self.tr(self.groupId())
        return '1 Bk generation (core)'

    def groupId(self):
        """
        Returns the unique ID of the group this algorithm belongs to. This
        string should be fixed for the algorithm, and must not be localised.
        The group id should be unique within each provider. Group id should
        contain lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'tbkcore'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return AlgorithmCreateStands()
